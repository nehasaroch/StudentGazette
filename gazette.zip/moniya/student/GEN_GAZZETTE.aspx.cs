﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GEN_GAZZETTE : System.Web.UI.Page
{
    static int TOT;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label_DATE.Text = DateTime.Now.ToShortDateString();
            
    }
    protected void Butto_sub_Click(object sender, EventArgs e)
    {
        //butto
        Text_roll.Text = DropDownLi_roll.SelectedItem.Text;
    }
    protected void B_DISP_Click(object sender, EventArgs e)
    {
        int SUB1, SUB2, SUB3, SUB4, SUB5;
        SUB1 = int.Parse(GridV_SUB1.Rows[0].Cells[2].Text);
        SUB2 = int.Parse(GridV_SUB2.Rows[0].Cells[2].Text);
        SUB3 = int.Parse(GridV_SUB3.Rows[0].Cells[2].Text);
        SUB4 = int.Parse(GridV_SUB4.Rows[0].Cells[2].Text);
        SUB5 = int.Parse(GridV_SUB5.Rows[0].Cells[2].Text);
        TOT = SUB1 + SUB2 + SUB3 + SUB4 + SUB5;
        Label_TOT.Text = TOT.ToString();
        Label_NAME.Text = GridVie_GAZ.Rows[0].Cells[1].Text;

        Label_SUB1.Text = SUB1.ToString();
        Label_SUB2.Text = SUB2.ToString();
        Label_SUB3.Text = SUB3.ToString();
        Label_SUB4.Text = SUB4.ToString();
        Label_SUB5.Text = SUB5.ToString();


        SUB1_NAME.Text = GridV_SUB1.Rows[0].Cells[0].Text;
        SUB2_NAME.Text = GridV_SUB2.Rows[0].Cells[0].Text;
        SUB3_NAME.Text = GridV_SUB3.Rows[0].Cells[0].Text;
        SUB4_NAME.Text = GridV_SUB4.Rows[0].Cells[0].Text;

        SUB5_NAME.Text = GridV_SUB5.Rows[0].Cells[0].Text;

        PASS_MARKS1.Text = "40";
        PASS_MARKS2.Text = "40";
        PASS_MARKS3.Text = "40";
        PASS_MARKS4.Text = "40";
        PASS_MARKS5.Text = "40";

        TO_MARKS1.Text = "100";
        TO_MARKS2.Text = "100";
        TO_MARKS3.Text = "100";
        TO_MARKS4.Text = "100";
        TO_MARKS5.Text = "100";

        TOTAL_MARKS.Text = "500";



    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        S_mark.InsertParameters.Add("@ROLLNO", Text_roll.Text);
        S_mark.InsertParameters.Add("@NAME", Label_NAME.Text);
        S_mark.InsertParameters.Add("@SUB1", SUB1_NAME.Text);
        S_mark.InsertParameters.Add("@SUB2" , SUB2_NAME.Text);
        S_mark.InsertParameters.Add("@SUB3" , SUB3_NAME.Text);
        S_mark.InsertParameters.Add("@SUB4" , SUB4_NAME.Text);
        S_mark.InsertParameters.Add("@SUB5" , SUB5_NAME.Text);
        S_mark.InsertParameters.Add("@SUB1_MO",Label_SUB1.Text);
        S_mark.InsertParameters.Add("@SUB2_MO", Label_SUB2.Text);
        S_mark.InsertParameters.Add("@SUB3_MO", Label_SUB3.Text);
        S_mark.InsertParameters.Add("@SUB4_MO", Label_SUB4.Text);
        S_mark.InsertParameters.Add("@SUB5_MO", Label_SUB5.Text);
        S_mark.InsertParameters.Add("@TOTAL_MO",Label_TOT.Text);
        S_mark.InsertParameters.Add("@TOTAL", TOTAL_MARKS.Text);
        S_mark.InsertParameters.Add("@SUB1_MIN", PASS_MARKS1.Text);
        S_mark.InsertParameters.Add("@SUB2_MIN", PASS_MARKS2.Text);
        S_mark.InsertParameters.Add("@SUB3_MIN", PASS_MARKS3.Text);
        S_mark.InsertParameters.Add("@SUB4_MIN", PASS_MARKS4.Text);
        S_mark.InsertParameters.Add("@SUB5_MIN", PASS_MARKS5.Text);
        S_mark.InsertParameters.Add("@SUB1_TM", TO_MARKS1.Text);
        S_mark.InsertParameters.Add("@SUB2_TM", TO_MARKS2.Text);
        S_mark.InsertParameters.Add("@SUB3_TM", TO_MARKS3.Text);
        S_mark.InsertParameters.Add("@SUB4_TM", TO_MARKS4.Text);
        S_mark.InsertParameters.Add("@SUB5_TM", TO_MARKS5.Text);
        S_mark.InsertParameters.Add("@DATE", Label_DATE.Text);
        S_mark.Insert();


    }
}