﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login_page : System.Web.UI.Page
{
    /*
    static string str;
    static string stud1, stud2, stud3, stud4;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void BUT_1_Click(object sender, EventArgs e)
    {
        str = Grid_LOG.Rows[0].Cells[0].Text;
        int r, ruser, ruser1, ruser2;




        stud1 = "monika";
        ruser = stud1.CompareTo(Text1_NAME.Text);

        stud2 = "ayush";
        ruser1 = stud2.CompareTo(Text1_NAME.Text);


        stud3 = "priya";
        ruser2 = stud3.CompareTo(Text1_NAME.Text);

        r = str.CompareTo(Text2_PAS.Text);

        if (r == 0 && ruser == 0)
        {
            Lit_LOG.Text = "yes";
            Response.Redirect("http://localhost:51837/student/SUBJECT_DETAILS_06_03_23aspx.aspx");

            
        }

        else
        {
             Lit_LOG.Text = "invalid password";
             Text2_PAS.Text = "";
            
        }

        if (r == 0 && ruser1 == 0)
        {
            Lit_LOG.Text = "yes";
            Response.Redirect("http://localhost:51837/student/STUDENT_DETAILS_06_03_23.aspx");
        }

        else
        {
            Lit_LOG.Text = "invalid password";
            Text2_PAS.Text = "";
        }
        if (r == 0 && ruser2 == 0)
        {
            Lit_LOG.Text = "yes";
            Response.Redirect("http://localhost:51837/student/SUB1_DETAILS_06_03_23.aspx");
        }
        else
        {
            Lit_LOG.Text = "invalid password";
            Text2_PAS.Text = "";
        }
    }*/

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void BUT_1_Click(object sender, EventArgs e)
    {
        string un = Text1_NAME.Text;
        string pw = Text2_PAS.Text;


        if (un == "monika" && pw == "m123")
        {
            Response.Redirect("http://localhost:51837/student/result_sec.aspx");
        }

        else if (un == "ayush" && pw == "a111")
        {
            Response.Redirect("http://localhost:51837/student/result_sec.aspx");
        }
        else if (un == "priya" && pw == "p212")
        {
            Response.Redirect("http://localhost:51837/student/result_sec.aspx");
        }
        else if (un == "Admin" && pw == "Admin")
        {
            Response.Redirect("http://localhost:51837/student/admin_sec.aspx");
        }
        else
        {
            Lit_LOG.Text = "incorrect username or password";
        }
        
    }
}