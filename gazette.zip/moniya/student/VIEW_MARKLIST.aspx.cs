﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VIEW_MARKLIST : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Butto_sub_Click(object sender, EventArgs e)
    {
        Text_roll.Text = DropDownLi_roll.SelectedItem.Text;
    }
    protected void B_DISP_Click(object sender, EventArgs e)
    {
        //MARKS OBTAINED
        int SUB1, SUB2, SUB3, SUB4, SUB5, TOT;
        SUB1 = int.Parse(grid_marklist.Rows[0].Cells[7].Text);
        SUB2 = int.Parse(grid_marklist.Rows[0].Cells[8].Text);
        SUB3 = int.Parse(grid_marklist.Rows[0].Cells[9].Text);
        SUB4 = int.Parse(grid_marklist.Rows[0].Cells[10].Text);
        SUB5 = int.Parse(grid_marklist.Rows[0].Cells[11].Text);
       
       TOT = SUB1 + SUB2 + SUB3 + SUB4 + SUB5;
        Label_TOT.Text = TOT.ToString();
        Label_NAME.Text = grid_marklist.Rows[0].Cells[1].Text;
        Label_F.Text = GridView1.Rows[0].Cells[2].Text;
        LABELTM.Text = Label_TOT.Text;
        Label2.Text = GridView1.Rows[0].Cells[4].Text;
        Label_DATE.Text = grid_marklist.Rows[0].Cells[24].Text;
        
       
        Label_SUB1.Text = SUB1.ToString();
        Label_SUB2.Text = SUB2.ToString();
        Label_SUB3.Text = SUB3.ToString();
        Label_SUB4.Text = SUB4.ToString();
        Label_SUB5.Text = SUB5.ToString();

        //SUBJECT NAME
        SUB1_NAME.Text =grid_marklist.Rows[0].Cells[2].Text;
        SUB2_NAME.Text = grid_marklist.Rows[0].Cells[3].Text;
        SUB3_NAME.Text =grid_marklist.Rows[0].Cells[4].Text;
        SUB4_NAME.Text = grid_marklist.Rows[0].Cells[5].Text;

        SUB5_NAME.Text = grid_marklist.Rows[0].Cells[6].Text;

        PASS_MARKS1.Text = "40";
        PASS_MARKS2.Text = "40";
        PASS_MARKS3.Text = "40";
        PASS_MARKS4.Text = "40";
        PASS_MARKS5.Text = "40";

        TO_MARKS1.Text = "100";
        TO_MARKS2.Text = "100";
        TO_MARKS3.Text = "100";
        TO_MARKS4.Text = "100";
        TO_MARKS5.Text = "100";

        TOTAL_MARKS.Text = "500";
    }
}