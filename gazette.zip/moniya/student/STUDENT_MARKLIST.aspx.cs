﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;

public partial class STUDENT_MARKLIST : System.Web.UI.Page
{
    private void GetAll()
    {
        string connectionStr = WebConfigurationManager.ConnectionStrings["ADD_SQL"].ToString();
        string command = "SELECT * FROM tabStudent";
        SqlDataAdapter adp = new SqlDataAdapter(command, connectionStr);
        DataTable studentTable = new DataTable("student");
        adp.Fill(studentTable);
        GridView1.DataSource = studentTable;
        GridView1.DataBind();

    }

    protected void Page_Load(object sender, EventArgs e)
    {

        GetAll();

    }




    protected void Button1_sear_Click(object sender, EventArgs e)
    {
        string rollno = Text_MARK.Text;
        string connectionStr = WebConfigurationManager.ConnectionStrings["ADD_SQL"].ToString();
        string command = "SELECT * FROM tabStudent where rollno=" + rollno;
        SqlDataAdapter adp = new SqlDataAdapter(command, connectionStr);
        DataTable studentTable = new DataTable("student");
        adp.Fill(studentTable);

        if (studentTable.Rows.Count > 0)
        {
            TextBox2_name.Text = studentTable.Rows[0]["name"].ToString();
            TextBox3_cour.Text = studentTable.Rows[0]["course"].ToString();
            //CheckBox1.Checked = Convert.ToBoolean(studentTable.Rows[0]["Pass"].ToString());

            Literal1.Text = "record found!";
        }
        else
        {
            Literal1.Text = "roll no not exist";
            TextBox2_name.Text = "";
            TextBox3_cour.Text = "";
            //CheckBox1.Checked = false;
        }

    }

}