﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LOGIN_USER_DETAIL : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void But_ADD_Click(object sender, EventArgs e)
    {
        //CODING INSERT INTO LOGIN_ADD(USER_NAME, PASSWORD) VALUES (@USER_NAME, @PASSWORD)
        SqlData_LOGIN.InsertParameters.Add("@USER_NAME", Text_NAME.Text);
        SqlData_LOGIN.InsertParameters.Add("@PASSWORD", Text_PASSW.Text);
        SqlData_LOGIN.Insert();
        
    }
    protected void SqlData_LOGIN_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}